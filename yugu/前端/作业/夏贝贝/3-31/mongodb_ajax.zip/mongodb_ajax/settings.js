module.exports ={
    cookieSecret:'xbb',
    db:'ajax_login',
    host:'localhost',
    prot:27017
}