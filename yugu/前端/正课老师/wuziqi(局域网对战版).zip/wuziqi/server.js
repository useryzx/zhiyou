var os=require('os');
// iptable={},
var ip;
ifaces=os.networkInterfaces();
for (var dev in ifaces) {
ifaces[dev].forEach(function(details,alias){
if (details.family=='IPv4') {
//   iptable[dev+(alias?':'+alias:'')]=details.address;
    if(!details.address.startsWith("127")){
        ip = details.address
    }
}
});
}
console.log(ip);


const express = require("express");
const session = require("express-session");
const ws = require("ws");
const http = require("http");
const path = require("path");
const url = require("url");

const app = express();
app.use(express.static("www"));

app.set("views",path.join(__dirname,"views"));
app.set("view engine","ejs");

app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true
}));

var server = http.createServer(app);

//匹配队列
const playerTemp = [];

//已匹配到对手的玩家
const playerList = [];


//webSocket服务器
const wss = new ws.Server({server:server});
wss.on("connection",function(ws,req){
    var urlObj = url.parse(req.url);
    // console.log(urlObj.query);
    
    ws.account = urlObj.query;
    playerTemp.push(ws);

    if(playerTemp.length>1){
        var p1 = playerTemp.pop();
        var p2 = playerTemp.pop();
        p1.oppo = p2;
        p2.oppo = p1;
        playerList.push(p1);
        playerList.push(p2);
        if(Math.random()>0.5){
            var te = p1;
            p1 = p2;
            p2 = te;
        }
        p1.send(JSON.stringify({
            msg:"start",
            color:"black",
            oppo:p2.account
        }));
        p2.send(JSON.stringify({
            msg:"start",
            color:"white",
            oppo:p1.account
        }));
        p1.active = true;
        p2.active = false;
    }
    

    //当本连接对象的用户发送来消息的事件
    ws.on("message",function(m){
        var order = JSON.parse(m);
        switch (order.msg) {
            case "put":
            if(ws.active&&playerList.indexOf(ws)>=0){
                ws.oppo.send(m);
                ws.active = false;
                ws.oppo.active = true;
            }
                break;
        
            default:
                break;
        }

        
    });

    ws.on("close",function(){
        var ind = playerList.indexOf(ws);
        if(ind>=0){
            try {
                ws.oppo.send(JSON.stringify({msg:"oppoLeave"}));
            } catch (error) {
                
            }
            playerList.splice(ind,1);
        }

    });

});




//http接口
app.get("/api/login",function(req,res){
    var account = req.query.account;
    if(!account.trim()){
        res.send(`
        <script>
            alert("用户名不能为空");
            history.back();
        </script>
        `);
    }else{
        req.session.account = account;
        res.redirect("/game");
    }
});


//游戏页面接口
app.get("/game",function(req,res){
    // console.log(2);
    // console.log(path.join(__dirname, './pages', 'game.html'));
    if(!req.session.account){
        res.send(`
        <script>
            alert("请先登录");
            location.href = "/";
        </script>
        `);
    }

    res.render("game",{
        account:req.session.account,
        ip:ip
    });
    // res.sendFile("./pages/game.html");
})





server.listen(3000,function(){
    console.log("服务器已开启");
});